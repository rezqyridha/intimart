<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span>© <?= date('Y') ?> PT. Intiboga Mandiri. All rights reserved.</span>
    </div>
</footer>
</div>
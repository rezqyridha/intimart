<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/intimart/config/constants.php';
require_once AUTH_PATH . '/session.php';
require_once CONFIG_PATH . '/koneksi.php';

if (!in_array($_SESSION['role'], ['admin', 'manajer'])) {
    header("Location: " . BASE_URL . "/unauthorized.php");
    exit;
}

$query = "
    SELECT ptl.*, b.nama_barang, b.satuan
    FROM produk_tidak_laku ptl
    JOIN barang b ON ptl.id_barang = b.id
    ORDER BY ptl.created_at DESC
";
$result = $koneksi->query($query);

require_once LAYOUTS_PATH . '/head.php';
require_once LAYOUTS_PATH . '/header.php';
require_once LAYOUTS_PATH . '/topbar.php';
require_once LAYOUTS_PATH . '/sidebar.php';
?>

<div class="main-content app-content">
    <div class="container-fluid">
        <div class="card custom-card mt-5 shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Laporan Produk Tidak Laku</h5>
                <a href="add.php" class="btn btn-sm btn-primary">
                    <i class="fe fe-plus me-1"></i> Tambah Laporan
                </a>
            </div>

            <div class="card-body">
                <div class="mb-3 d-flex justify-content-end">
                    <input type="text" id="searchBox" class="form-control w-25" placeholder="Cari...">
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle mb-0" id="tabel-tidaklaku">
                        <thead class="table-primary">
                            <tr>
                                <th>No</th>
                                <th>Barang</th>
                                <th>Periode</th>
                                <th>Jumlah Terjual</th>
                                <th>Status</th>
                                <th>Keterangan</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama_barang']) ?> (<?= $row['satuan'] ?>)</td>
                                    <td><?= date('d/m/Y', strtotime($row['periode_awal'])) ?> s/d <?= date('d/m/Y', strtotime($row['periode_akhir'])) ?></td>
                                    <td><?= $row['jumlah_terjual'] ?></td>
                                    <td>
                                        <?php
                                        $status = $row['status'];
                                        $badge = match ($status) {
                                            'diperiksa' => 'secondary',
                                            'tindaklanjut' => 'warning',
                                            'selesai' => 'success',
                                            default => 'dark'
                                        };
                                        ?>
                                        <span class="badge bg-<?= $badge ?> text-capitalize"><?= $status ?></span>
                                    </td>
                                    <td><?= nl2br(htmlspecialchars($row['keterangan'])) ?></td>
                                    <td class="text-center">
                                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-info me-1" title="Edit">
                                            <i class="fe fe-edit"></i>
                                        </a>
                                        <button onclick="confirmDelete('delete.php?id=<?= $row['id'] ?>')" class="btn btn-sm btn-danger btn-icon" title="Hapus">
                                            <i class="fe fe-trash-2"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once LAYOUTS_PATH . '/footer.php'; ?>
<?php require_once LAYOUTS_PATH . '/scripts.php'; ?>

<script>
    document.getElementById("searchBox").addEventListener("input", function() {
        const filter = this.value.toLowerCase();
        document.querySelectorAll("#tabel-tidaklaku tbody tr").forEach(row => {
            row.style.display = row.innerText.toLowerCase().includes(filter) ? "" : "none";
        });
    });
</script>
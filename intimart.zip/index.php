<?php
// Redirect ke halaman login
header("Location: auth/login.php");
exit;
